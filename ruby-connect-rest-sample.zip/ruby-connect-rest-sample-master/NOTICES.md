This project uses the following third-party components:

Ruby, which is copyright (c) free software by [Yukihiro Matsumoto](matz@netlab.jp), and is available under the terms of the [2-clause BSD License](https://opensource.org/licenses/BSD-2-Clause).

Ruby on Rails, which is a registered trademark (TM) of David Heinemeier Hansson, and is available under the [MIT License](http://www.opensource.org/licenses/mit-license.php). 

Rack, which is copyright (c) Christian Neukirchen, and is available under the [MIT License](http://www.opensource.org/licenses/mit-license.php).
# Be sure to restart your server when you modify this file.

# rubocop:disable Metrics/LineLength
Rails.application.config.session_store :cookie_store, key: '_o365-ruby-unified-api-connect_session'
# rubocop:enable Metrics/LineLength
